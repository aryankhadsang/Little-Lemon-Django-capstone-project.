# Little Lemon Booking System

Django + MySQL booking app for the peer-graded Little Lemon booking-system assignment.

## Included
- Django project `littlelemon` and app `restaurant`
- MySQL database configuration in `littlelemon/settings.py`
- Booking model with a database uniqueness constraint on `(reservation_date, reservation_slot)`
- Booking form with First name, date picker, and reservation slot
- JavaScript Fetch API calls to refresh bookings when the date changes
- Already-booked time slots are disabled in the form
- JSON reservations page at `/reservations/`
- Date-filtered API at `/bookings?date=YYYY-MM-DD`
- Empty dates show `No Booking`

## Setup (Windows PowerShell or terminal)

1. Install Python 3.11 and MySQL Server. Create the database:
   ```sql
   CREATE DATABASE littlelemon CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```
2. Install pipenv if needed:
   ```bash
   pip install pipenv
   ```
3. From this folder:
   ```bash
   pipenv install
   ```
4. Edit `littlelemon/settings.py` or set environment variables to match your local MySQL credentials:
   - `MYSQL_DATABASE` (default `littlelemon`)
   - `MYSQL_USER` (default `root`)
   - `MYSQL_PASSWORD` (default placeholder `your_mysql_password`)
   - `MYSQL_HOST` (default `127.0.0.1`)
   - `MYSQL_PORT` (default `3306`)
5. Create tables and start the server:
   ```bash
   pipenv run python manage.py makemigrations restaurant
   pipenv run python manage.py migrate
   pipenv run python manage.py runserver
   ```
6. Open:
   - Booking form: http://127.0.0.1:8000/book/
   - All reservations JSON: http://127.0.0.1:8000/reservations/
   - API for a date: http://127.0.0.1:8000/bookings?date=2026-10-15

## Notes
- This is a standalone implementation based on the assignment criteria and supplied screenshots. If your course starter project contains additional provided pages/assets, you can merge them into this project.
- A successful reservation POST is handled by `/create-booking/`; if you want to test it manually, submit the form on `/book/`.
- The database-level uniqueness constraint prevents duplicate bookings even if two users try to book the same slot at nearly the same time.
