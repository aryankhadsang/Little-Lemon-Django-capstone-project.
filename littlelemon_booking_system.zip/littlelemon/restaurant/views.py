import json
from datetime import date
from django.http import JsonResponse, HttpResponseBadRequest
from django.shortcuts import render
from django.views.decorators.http import require_GET, require_POST
from django.db import IntegrityError, transaction
from .models import Booking

def home(request):
    return render(request, "restaurant/home.html")

def book(request):
    return render(request, "restaurant/book.html")

def reservations(request):
    # Django's standard JSON serialization format, as requested by the assignment.
    return JsonResponse(
        json.loads(__import__("django.core.serializers").core.serializers.serialize("json", Booking.objects.all())),
        safe=False,
    )

@require_GET
def bookings_api(request):
    requested_date = request.GET.get("date")
    queryset = Booking.objects.all()
    if requested_date:
        try:
            date.fromisoformat(requested_date)
        except ValueError:
            return HttpResponseBadRequest("Invalid date. Use YYYY-MM-DD.")
        queryset = queryset.filter(reservation_date=requested_date)
    data = [
        {
            "id": booking.pk,
            "first_name": booking.first_name,
            "reservation_date": booking.reservation_date.isoformat(),
            "reservation_slot": booking.reservation_slot,
        }
        for booking in queryset
    ]
    return JsonResponse(data, safe=False)

@require_POST
def create_booking(request):
    try:
        payload = json.loads(request.body)
        first_name = str(payload.get("first_name", "")).strip()
        reservation_date = date.fromisoformat(payload.get("reservation_date", ""))
        reservation_slot = int(payload.get("reservation_slot"))
    except (json.JSONDecodeError, TypeError, ValueError):
        return JsonResponse({"error": "Please provide a name, valid date, and time slot."}, status=400)

    if not first_name:
        return JsonResponse({"error": "First name is required."}, status=400)
    if reservation_slot not in range(10, 21):
        return JsonResponse({"error": "Choose a valid reservation slot."}, status=400)
    if reservation_date < date.today():
        return JsonResponse({"error": "Reservation date cannot be in the past."}, status=400)

    try:
        with transaction.atomic():
            booking = Booking.objects.create(
                first_name=first_name,
                reservation_date=reservation_date,
                reservation_slot=reservation_slot,
            )
    except IntegrityError:
        return JsonResponse({"error": "That time is already booked for this date."}, status=409)

    return JsonResponse({
        "message": "Reservation created successfully.",
        "booking": {
            "id": booking.pk,
            "first_name": booking.first_name,
            "reservation_date": booking.reservation_date.isoformat(),
            "reservation_slot": booking.reservation_slot,
        },
    }, status=201)
