const form = document.getElementById("booking-form");
const dateInput = document.getElementById("reservation_date");
const slotSelect = document.getElementById("reservation_slot");
const bookingList = document.getElementById("booking-list");
const heading = document.getElementById("booking-heading");
const message = document.getElementById("form-message");

function localToday() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,"0")}-${String(now.getDate()).padStart(2,"0")}`;
}
dateInput.value = localToday();
dateInput.min = localToday();

function displayTime(hour) {
  const h = Number(hour);
  return `${h > 12 ? h - 12 : h} ${h >= 12 ? "PM" : "AM"}`;
}

async function refreshBookings() {
  const selectedDate = dateInput.value;
  if (!selectedDate) return;
  heading.textContent = `Bookings For ${selectedDate}`;
  try {
    const response = await fetch(`/bookings?date=${encodeURIComponent(selectedDate)}`);
    if (!response.ok) throw new Error("Could not retrieve bookings.");
    const bookings = await response.json();
    bookingList.replaceChildren();
    const bookedSlots = new Set(bookings.map(item => Number(item.reservation_slot)));
    for (const option of slotSelect.options) {
      const slot = Number(option.value);
      if (!option.value) continue;
      option.disabled = bookedSlots.has(slot);
      option.textContent = `${displayTime(slot)}${option.disabled ? " (Booked)" : ""}`;
    }
    if (bookings.length === 0) {
      const li = document.createElement("li");
      li.textContent = "No Booking";
      bookingList.appendChild(li);
    } else {
      bookings.forEach(booking => {
        const li = document.createElement("li");
        li.textContent = `${booking.first_name} - ${displayTime(booking.reservation_slot)}`;
        bookingList.appendChild(li);
      });
    }
  } catch (error) {
    bookingList.replaceChildren();
    const li = document.createElement("li");
    li.textContent = "Unable to load bookings. Check the server connection.";
    bookingList.appendChild(li);
  }
}
dateInput.addEventListener("change", refreshBookings);

form.addEventListener("submit", async event => {
  event.preventDefault();
  message.textContent = "";
  const csrf = document.querySelector("[name=csrfmiddlewaretoken]").value;
  const payload = {
    first_name: document.getElementById("first_name").value.trim(),
    reservation_date: dateInput.value,
    reservation_slot: slotSelect.value
  };
  try {
    const response = await fetch("/create-booking/", {
      method: "POST",
      headers: {"Content-Type": "application/json", "X-CSRFToken": csrf},
      body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Reservation failed.");
    message.textContent = result.message;
    form.reset();
    dateInput.value = payload.reservation_date;
    await refreshBookings();
  } catch (error) {
    message.textContent = error.message;
  }
});
refreshBookings();
